# EdiahBot
Bot Discord FiveM avec le nombre de joueurs connectés et un peu d'auto-moderation ! 


Tout droits reservées a Aznyrr et EdiahDEV AND LEAK
